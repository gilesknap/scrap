from tidy import tidy_folder, tidy_name


def test_tidy_name():
    assert tidy_name("My Holiday Photo (1).JPG") == "my-holiday-photo-1.jpg"


def test_tidy_name_no_extension():
    assert tidy_name("READ ME") == "read-me"


def test_tidy_folder_renames(tmp_path):
    (tmp_path / "Tax Return 2025.PDF").write_text("x")
    assert tidy_folder(tmp_path) == [("Tax Return 2025.PDF", "tax-return-2025.pdf")]
    assert (tmp_path / "tax-return-2025.pdf").exists()
