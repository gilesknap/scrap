# --dry-run renames files anyway

`tidy --dry-run ~/Downloads` printed the changes it would make, then made them:
every file in the folder was renamed. A dry run should only print.

Expected: with `-n` / `--dry-run`, tidy prints `old -> new` for each file and
leaves the folder exactly as it was. Please add a test.
