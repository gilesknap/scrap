"""tidy: give the files in a folder clean, consistent names."""

import argparse
import re
from pathlib import Path


def tidy_name(name: str) -> str:
    """'My Holiday Photo (1).JPG' -> 'my-holiday-photo-1.jpg'."""
    stem, dot, ext = name.rpartition(".")
    if not dot:
        stem, ext = name, ""
    stem = re.sub(r"[^a-z0-9]+", "-", stem.lower()).strip("-")
    return f"{stem}.{ext.lower()}" if ext else stem


def tidy_folder(folder: Path, dry_run: bool = False) -> list[tuple[str, str]]:
    """Rename every file in folder to its tidy name; the (old, new) pairs."""
    changes = []
    for path in sorted(folder.iterdir()):
        if not path.is_file():
            continue
        new = tidy_name(path.name)
        if new != path.name:
            changes.append((path.name, new))
            path.rename(path.with_name(new))
    return changes


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="tidy", description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("-n", "--dry-run", action="store_true",
                        help="show what would change, rename nothing")
    args = parser.parse_args(argv)
    for old, new in tidy_folder(args.folder, args.dry_run):
        print(f"{old} -> {new}")


if __name__ == "__main__":
    main()
