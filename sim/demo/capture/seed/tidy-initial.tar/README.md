# tidy

Give the files in a folder clean, consistent names.

    uv run tidy.py ~/Downloads --dry-run

Tests: `uv run pytest -q`
